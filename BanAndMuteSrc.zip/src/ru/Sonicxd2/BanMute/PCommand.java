/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.Sonicxd2.BanMute;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/**
 *
 * @author Yaroslav
 */
public class PCommand implements CommandExecutor{

    @Override
    public boolean onCommand(CommandSender cs, Command cmnd, String string, String[] strings) {
        if(!cs.hasPermission(Main.instance.permissions)) {
            cs.sendMessage(ChatColor.translateAlternateColorCodes('&', Main.instance.no_permission));
            return true;
        }
        
        if(strings.length!=2){
            cs.sendMessage(ChatColor.RED+"Недостаточно аргументов");
            return true;
        }

        if(Main.instance.getSuperConfig().getString(strings[1])==null){
            cs.sendMessage(ChatColor.RED+"Правило не найдено.");
            return true;
        }
        //  cs.sendMessage(strings[1]);
        //  cs.sendMessage(Main.instance.getSuperConfig().getString(strings[1]));
        String[] Commands=Main.instance.getSuperConfig().getString(strings[1]).split(";");
        for(String command:Commands){
            Bukkit.dispatchCommand(cs, command.replaceAll("%player%", strings[0]));
        }
        
        return true;
    }
    
}
