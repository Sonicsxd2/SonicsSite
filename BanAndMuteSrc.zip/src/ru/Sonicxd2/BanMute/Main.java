/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.Sonicxd2.BanMute;

import java.io.File;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 *
 * @author Yaroslav
 */
public class Main extends JavaPlugin{
    public static Main instance=null;
    String permissions="banandmute";
    String no_permission="&4 У вас нет прав.";  

    @Override
    public void onLoad() {
        instance=this;
    }
    
    @Override
    public void onEnable() {
        saveDefaultConfig();
        permissions=getConfig().getString("permission");
        no_permission=getConfig().getString("No_PermissionMessage");
        getCommand("p").setExecutor(new PCommand());
    }
    public YamlConfiguration getSuperConfig(){
        File f=new File(getDataFolder(),"config.yml");
        YamlConfiguration yc=YamlConfiguration.loadConfiguration(f);
        return yc;
    }

    
}
